# Computer Networks Lab Experiments

**Course:** 21CSC302J – Computer Networks (Semester V)
**Name:** K.S. Yashvin Kumar
**Register No.:** R2411030050007
**Tool:** Cisco Packet Tracer

## Contents

| No. | Experiment | Topics |
|-----|------------|--------|
| 1 | [Packet Tracer, Peer-to-Peer Communication and Cable Study](#experiment-1) | Packet Tracer basics, IP addressing, ping, straight-through and crossover cables, T568A/T568B |
| 2 | [Router Configuration](#experiment-2) | Console, enable and VTY passwords, interface configuration, inter-network ping |

## Repository Structure

```
CN-Lab-Experiments/
├── README.md
├── configs/
│   └── lab3_router_config.txt
└── screenshots/
    ├── exp1_01_topology.png
    ├── exp1_02_pc0_ip.png
    ├── exp1_03_pc1_ip.png
    ├── exp1_04_ping.png
    ├── exp2_02_passwords.png
    └── exp2_03_interfaces.png
```

---

<a id="experiment-1"></a>
## Experiment 1: Packet Tracer, Peer-to-Peer Communication and Cable Study

### Aim
To become familiar with Cisco Packet Tracer, build a two-PC network, verify communication using `ping`, and study Ethernet cable types and their colour codes.

### Components
| Item | Quantity |
|------|----------|
| PC-PT | 2 |
| Switch 2960-24TT | 1 |
| Copper straight-through cable | 2 |

### Addressing Table
| Device | IP Address | Subnet Mask |
|--------|------------|-------------|
| PC0 | 192.168.1.1 | 255.255.255.0 |
| PC1 | 192.168.1.2 | 255.255.255.0 |

### Procedure
1. Open Cisco Packet Tracer and review the workspace, device palette and toolbar.
2. Place two PCs (PC0, PC1) and one 2960 switch on the workspace.
3. Connect each PC to the switch using a **copper straight-through** cable.

   ![Network topology](screenshots/exp1_01_topology.png)

4. On PC0, open **Desktop → IP Configuration** and assign `192.168.1.1` with mask `255.255.255.0`.

   ![PC0 IP configuration](screenshots/exp1_02_pc0_ip.png)

5. On PC1, assign `192.168.1.2` with mask `255.255.255.0`.

   ![PC1 IP configuration](screenshots/exp1_03_pc1_ip.png)

6. On PC0, open **Desktop → Command Prompt** and run:

   ```
   ping 192.168.1.2
   ```

   ![Ping output](screenshots/exp1_04_ping.png)

### Cable Study

| Cable | Used to connect | Wiring |
|-------|-----------------|--------|
| Straight-through | Unlike devices (PC–switch, router–switch) | T568B on both ends |
| Crossover | Like devices (PC–PC, switch–switch, PC–router) | T568A on one end, T568B on the other |

| Pin | T568B | T568A |
|-----|-------|-------|
| 1 | White/Orange | White/Green |
| 2 | Orange | Green |
| 3 | White/Green | White/Orange |
| 4 | Blue | Blue |
| 5 | White/Blue | White/Blue |
| 6 | Green | Orange |
| 7 | White/Brown | White/Brown |
| 8 | Brown | Brown |

### Output
PC0 received replies to all four echo requests from 192.168.1.2 (Sent = 4, Received = 4, Lost = 0, 0% loss, TTL = 128).

### Result
A two-PC network was built through a switch, both hosts were addressed in 192.168.1.0/24, and connectivity was verified with `ping`. The straight-through and crossover cable colour codes were studied.

---

<a id="experiment-2"></a>
## Experiment 2: Router Configuration

### Aim
To configure console, enable and VTY passwords on a router, configure its interfaces, and verify connectivity between two networks through the router.

### Components
| Item | Quantity |
|------|----------|
| Router 2911 | 1 |
| PC-PT | 2 |
| Copper crossover cable | 2 |

### Addressing Table
| Device | Interface | IP Address | Subnet Mask | Default Gateway |
|--------|-----------|------------|-------------|-----------------|
| R1 | Gig0/1 | 192.168.1.1 | 255.255.255.0 | – |
| R1 | Gig0/2 | 192.168.2.1 | 255.255.255.0 | – |
| PC0 | NIC | 192.168.1.2 | 255.255.255.0 | 192.168.1.1 |
| PC1 | NIC | 192.168.2.2 | 255.255.255.0 | 192.168.2.1 |

### Procedure
1. Place one router and two PCs on the workspace. Connect PC0 to Gig0/1 and PC1 to Gig0/2 using copper crossover cables.
2. Open the router **CLI** tab and enter privileged and global configuration modes:

   ```
   Router> enable
   Router# configure terminal
   Router(config)# hostname R1
   ```

3. Configure the console, enable and VTY passwords:

   ```
   R1(config)# line console 0
   R1(config-line)# password cisco
   R1(config-line)# login
   R1(config-line)# exit
   R1(config)# enable password cisco
   R1(config)# line vty 0 4
   R1(config-line)# password cisco
   R1(config-line)# login
   R1(config-line)# exit
   ```

   ![Password configuration](screenshots/exp2_02_passwords.png)

4. Configure the two router interfaces:

   ```
   R1(config)# interface gigabitEthernet0/1
   R1(config-if)# ip address 192.168.1.1 255.255.255.0
   R1(config-if)# no shutdown
   R1(config-if)# exit
   R1(config)# interface gigabitEthernet0/2
   R1(config-if)# ip address 192.168.2.1 255.255.255.0
   R1(config-if)# no shutdown
   R1(config-if)# end
   ```

   ![Interface configuration](screenshots/exp2_03_interfaces.png)

5. Verify that both interfaces are up:

   ```
   R1# show ip interface brief
   ```

6. Assign the IP addresses and default gateways from the addressing table to PC0 and PC1.
7. From PC0, test connectivity to PC1:

   ```
   ping 192.168.2.2
   ```

The complete command listing is in [`configs/lab3_router_config.txt`](configs/lab3_router_config.txt).

### Output
`show ip interface brief` lists GigabitEthernet0/1 and GigabitEthernet0/2 as up/up. The ping from PC0 (192.168.1.2) to PC1 (192.168.2.2) succeeds through the router; the first request may time out while ARP resolves the gateway.

### Result
Console, enable and VTY passwords and both router interfaces were configured, and the two networks communicated through the router.

---

## Conclusion
Both experiments were completed in Cisco Packet Tracer: peer-to-peer communication through a switch together with a study of Ethernet cable colour codes, and router password and interface configuration with routing between two networks.
